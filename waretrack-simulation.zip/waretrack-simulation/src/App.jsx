import React, { useMemo, useState } from 'react';
import {
  Activity, ArrowUpRight, Boxes, Building2, ChevronDown, Clock3,
  Construction, Gauge, MapPin, Package, Play, Search, Truck,
  Warehouse, Zap, MoreHorizontal, RotateCcw, X, Navigation, Layers3, DoorOpen,
} from 'lucide-react';
import WarehouseScene from './components/WarehouseScene.jsx';
import { assetCatalog, operations, shipmentSteps, sites } from './data/sites.js';
import { useWaretrackStore } from './store/useWaretrackStore.js';

function Sparkline({ variant = 0 }) {
  const paths = [
    'M1 18 C10 17 11 12 18 14 S27 19 34 11 S44 13 50 7 S61 10 70 3',
    'M1 15 C9 17 12 7 20 10 S30 18 38 12 S48 14 54 7 S63 12 70 4',
    'M1 18 C8 18 12 14 19 15 S28 10 35 12 S44 5 51 8 S62 2 70 3',
  ];
  return <svg className="sparkline" viewBox="0 0 72 22" preserveAspectRatio="none"><path d={paths[variant]} /></svg>;
}

function Header({ site, onSelectSite, onSelectAsset }) {
  const paused = useWaretrackStore((s) => s.paused);
  const togglePause = useWaretrackStore((s) => s.togglePause);
  const search = useWaretrackStore((s) => s.search);
  const setSearch = useWaretrackStore((s) => s.setSearch);
  const [menuOpen, setMenuOpen] = useState(false);
  const matches = useMemo(() => {
    if (!search.trim()) return [];
    const q = search.toLowerCase();
    const assetHits = assetCatalog.filter((a) => `${a.id} ${a.name} ${a.kind} ${a.status}`.toLowerCase().includes(q)).slice(0, 5);
    const siteHits = sites.filter((s) => `${s.name} ${s.city}`.toLowerCase().includes(q)).slice(0, 3);
    return [...siteHits.map((s) => ({ ...s, resultType: 'site' })), ...assetHits.map((a) => ({ ...a, resultType: 'asset' }))].slice(0, 7);
  }, [search]);
  const choose = (item) => {
    if (item.resultType === 'site') onSelectSite(item.id);
    else onSelectAsset(item.id);
    setSearch('');
  };
  return (
    <header className="topbar">
      <div className="brand-wrap">
        <div className="brand-mark"><Layers3 size={20} strokeWidth={2.3} /></div>
        <div className="brand-copy"><span>WARE<span className="brand-light">TRACK</span></span><small>OPERATIONS COMMAND</small></div>
      </div>
      <div className="header-search-wrap">
        <Search size={16} />
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search sites, trucks, forklifts, pallets, shipments..." aria-label="Search warehouse assets" />
        <kbd>⌘ K</kbd>
        {matches.length > 0 && <div className="search-results">
          <div className="search-results-label">MATCHING RECORDS</div>
          {matches.map((item) => <button key={`${item.resultType}-${item.id}`} onClick={() => choose(item)}>
            <span className="search-result-icon">{item.resultType === 'site' ? <Building2 size={15} /> : item.kind === 'truck' ? <Truck size={15} /> : item.kind === 'forklift' ? <Construction size={15} /> : <Package size={15} />}</span>
            <span className="search-result-main"><b>{item.name}</b><small>{item.resultType === 'site' ? item.city : `${item.kind.toUpperCase()} · ${item.status}`}</small></span>
            <span className="search-result-type">{item.resultType === 'site' ? 'SITE' : item.kind.toUpperCase()}</span>
          </button>)}
        </div>}
      </div>
      <div className="header-right">
        <div className="site-select-wrap">
          <button className={`site-select ${menuOpen ? 'open' : ''}`} onClick={() => setMenuOpen(!menuOpen)}>
            <span className="site-select-icon"><Warehouse size={16} /></span>
            <span className="site-select-copy"><small>ACTIVE FACILITY</small><b>{site.name}</b></span>
            <ChevronDown size={15} />
          </button>
          {menuOpen && <div className="site-menu">
            <div className="site-menu-heading">SWITCH FACILITY <span>5 SITES</span></div>
            {sites.map((s) => <button key={s.id} className={s.id === site.id ? 'active' : ''} onClick={() => { onSelectSite(s.id); setMenuOpen(false); }}>
              <span className="site-menu-dot" style={{ background: s.color }} />
              <span><b>{s.name}</b><small>{s.city} · {s.docks} docks</small></span>
              <span className="site-menu-capacity">{s.capacity}%</span>
            </button>)}
          </div>}
        </div>
        <button className={`live-control ${paused ? 'paused' : ''}`} onClick={togglePause} title={paused ? 'Resume simulation' : 'Pause simulation'}>
          {paused ? <Play size={13} fill="currentColor" /> : <span className="live-pulse" />}
          {paused ? 'PAUSED' : 'LIVE'}
        </button>
        <div className="profile">
          <div className="profile-avatar">AC</div>
          <div className="profile-copy"><b>Alex Chen</b><small>Operations Manager</small></div>
          <ChevronDown size={14} className="profile-chevron" />
        </div>
      </div>
    </header>
  );
}

function KpiStrip({ site }) {
  const seconds = useWaretrackStore((s) => s.simulationSeconds);
  const elapsed = Math.floor(seconds);
  const stock = site.stock + Math.floor(elapsed / 17);
  const trucks = Math.max(0, site.trucks + (Math.floor(elapsed / 23) % 3) - 1);
  const onTime = Math.min(99.9, site.onTime + (elapsed % 47) / 1000);
  const cards = [
    { label: 'STOCK ON HAND', value: stock.toLocaleString('en-US'), unit: 'units', delta: '+15', positive: true, note: 'vs. previous shift', icon: <Boxes size={16} />, variant: 0 },
    { label: 'TRUCKS ON SITE', value: String(trucks).padStart(2, '0'), unit: 'vehicles', delta: '+1', positive: true, note: 'vs. previous hour', icon: <Truck size={16} />, variant: 1 },
    { label: 'ON-TIME DELIVERY', value: `${onTime.toFixed(1)}%`, unit: 'service level', delta: '+0.4%', positive: true, note: 'vs. last 7 days', icon: <Gauge size={16} />, variant: 2 },
  ];
  return <section className="kpi-strip">
    <div className="kpi-context"><span className="eyebrow">NETWORK SNAPSHOT</span><span className="kpi-context-site"><MapPin size={13} /> {site.city}</span></div>
    {cards.map((c) => <div className="kpi-card" key={c.label}>
      <div className="kpi-card-top"><span>{c.label}</span><i>{c.icon}</i></div>
      <div className="kpi-card-bottom"><div><strong>{c.value}</strong><span>{c.unit}</span></div><Sparkline variant={c.variant} /><div className="kpi-delta"><span><ArrowUpRight size={12} /> {c.delta}</span><small>{c.note}</small></div></div>
    </div>)}
    <div className="kpi-updated"><span className="updated-dot" /> AUTO-REFRESH <b>2.5s</b></div>
  </section>;
}

function ShipmentTracker({ site }) {
  const [activeShipment, setActiveShipment] = useState(0);
  const simulationSeconds = useWaretrackStore((s) => s.simulationSeconds);
  const current = site.shipments[activeShipment % site.shipments.length];
  const progress = Math.min(82, 66 + Math.floor(simulationSeconds / 14) % 17);
  return <section className="shipment-panel panel">
    <div className="panel-heading shipment-heading">
      <div><span className="eyebrow">SHIPMENT TRACKER</span><h3>Outbound movement <span className="heading-count">03 ACTIVE</span></h3></div>
      <button className="text-button" onClick={() => setActiveShipment((v) => (v + 1) % site.shipments.length)}>Next shipment <ArrowUpRight size={13} /></button>
    </div>
    <div className="shipment-content">
      <div className="shipment-feature">
        <div className="shipment-id-row"><span className="shipment-icon"><Package size={16} /></span><div><b>#{current}</b><small>Priority freight · Retail replenishment</small></div><span className="status-pill status-transit">IN TRANSIT</span></div>
        <div className="shipment-route"><span>Memphis, TN</span><div className="route-line"><span className="route-point start" /><i /><span className="route-point end" /></div><span>St. Louis, MO</span></div>
        <div className="shipment-foot"><span><Navigation size={12} /> 284 mi remaining</span><span><Clock3 size={12} /> ETA 11:40 AM</span><b>{progress}%</b></div>
        <div className="progress-track shipment-progress"><i style={{ width: `${progress}%` }} /></div>
      </div>
      <div className="shipment-timeline">
        {shipmentSteps.map((step, i) => <div className={`milestone ${step.done ? 'done' : ''} ${step.current ? 'current' : ''}`} key={step.name}>
          <div className="milestone-mark">{step.done ? '✓' : step.current ? <span /> : ''}</div>
          <div className="milestone-copy"><b>{step.name}</b><small>{step.time}</small></div>
          {i < shipmentSteps.length - 1 && <div className={`milestone-connector ${step.done ? 'complete' : ''}`} />}
        </div>)}
      </div>
    </div>
  </section>;
}

function StatusPill({ status }) {
  const cls = status?.toLowerCase().includes('available') ? 'status-available'
    : status?.toLowerCase().includes('charging') ? 'status-charging'
    : status?.toLowerCase().includes('active') || status?.toLowerCase().includes('loading') || status?.toLowerCase().includes('unloading') ? 'status-active'
    : status?.toLowerCase().includes('depart') ? 'status-transit'
    : status?.toLowerCase().includes('reserved') || status?.toLowerCase().includes('yard') || status?.toLowerCase().includes('picked') ? 'status-warn'
    : 'status-neutral';
  return <span className={`status-pill ${cls}`}>{status}</span>;
}

function SiteOverview({ site }) {
  return <>
    <div className="inspector-hero">
      <div className="inspector-icon site-icon"><Building2 size={18} /></div>
      <div><span className="eyebrow">FACILITY OVERVIEW</span><h3>{site.name}</h3><p><MapPin size={12} /> {site.city}</p></div>
    </div>
    <div className="overview-status-row"><span>Operational status</span><StatusPill status={site.status} /></div>
    <div className="capacity-block">
      <div className="capacity-heading"><span>Storage capacity</span><b>{site.capacity}%</b></div>
      <div className="progress-track"><i style={{ width: `${site.capacity}%` }} /></div>
      <div className="capacity-foot"><span>{Math.floor(site.stock * site.capacity / 100).toLocaleString('en-US')} occupied positions</span><span>{Math.round(site.stock * (100 - site.capacity) / 100).toLocaleString('en-US')} available</span></div>
    </div>
    <div className="mini-stats-grid">
      <div><small>OUTBOUND TODAY</small><b>{site.outbound}</b><span>shipments</span></div>
      <div><small>PUT-AWAY QUEUE</small><b>{site.putAway}</b><span>pallets</span></div>
      <div><small>DOCK UTILIZATION</small><b>{Math.round(site.activeDocks / site.docks * 100)}%</b><span>{site.activeDocks}/{site.docks} active</span></div>
      <div><small>INBOUND TODAY</small><b>{site.inbound}</b><span>appointments</span></div>
    </div>
    <div className="inspector-section-title"><span>INVENTORY BY ZONE</span><button className="icon-button small"><MoreHorizontal size={16} /></button></div>
    <div className="inventory-table">
      <div className="inventory-row table-head"><span>ZONE</span><span>PALLETS</span><span>UTIL.</span></div>
      {[['A · Bulk storage', '4,280', '91%'], ['B · Pick faces', '3,640', '78%'], ['C · Staging', '2,160', '64%'], ['D · Reserve', '2,400', '82%']].map((r) => <div className="inventory-row" key={r[0]}><span>{r[0]}</span><b>{r[1]}</b><span className="zone-util">{r[2]}</span></div>)}
    </div>
    <div className="active-task-card"><div className="task-card-top"><span className="task-pulse" /> ACTIVE FORKLIFT TASK <b>FL-01</b></div><div className="task-card-row"><span>Loading order #{site.shipments[0]}</span><strong>76%</strong></div><div className="progress-track"><i style={{ width: '76%' }} /></div></div>
  </>;
}

function AssetInspector({ asset, site }) {
  if (!asset) return null;
  const icon = asset.kind === 'pallet' ? <Package size={18} /> : asset.kind === 'forklift' ? <Construction size={18} /> : asset.kind === 'truck' ? <Truck size={18} /> : asset.kind === 'charger' ? <Zap size={18} /> : <DoorOpen size={18} />;
  const details = asset.kind === 'pallet' ? [
    ['SKU', asset.sku], ['Quantity', `${asset.quantity} units`], ['Gross weight', asset.weight], ['Location', asset.location], ['Lot number', asset.lot], ['Received date', asset.received],
  ] : asset.kind === 'forklift' ? [
    ['Model', asset.model], ['Battery level', `${asset.battery}%`], ['Current task', asset.task], ['Carrying', asset.carrying], ['Moves today', asset.moves], ['Travel speed', asset.speed], ['Assigned charger', asset.charger],
  ] : asset.kind === 'truck' ? [
    ['Carrier', asset.carrier], ['Arrival / ETA', asset.eta], ['Shipment ID', asset.shipment], ['Assigned dock', asset.dock], ['Cargo manifest', asset.cargo], ['Route', asset.route],
  ] : asset.kind === 'charger' ? [
    ['Power output', asset.output], ['Connector', asset.connector], ['Bay location', asset.bay], ['Utilization', asset.utilization],
  ] : [
    ['Door', asset.door], ['Assigned vehicle', asset.truck], ['Shipment', asset.shipment], ['Load progress', `${asset.progress}%`],
  ];
  return <>
    <div className="inspector-hero">
      <div className={`inspector-icon ${asset.kind}-icon`}>{icon}</div>
      <div><span className="eyebrow">{asset.kind.toUpperCase()} DETAILS</span><h3>{asset.name}</h3><p><MapPin size={12} /> {site.name} · Yard A</p></div>
    </div>
    <div className="asset-status-strip"><span>Current status</span><StatusPill status={asset.status} /></div>
    {asset.kind === 'forklift' && <div className="battery-card"><div className="battery-head"><span><Zap size={13} /> BATTERY HEALTH</span><b>{asset.battery}%</b></div><div className="battery-track"><i style={{ width: `${asset.battery}%` }} /></div><small>{asset.battery < 25 ? 'Low battery · Return to charger' : 'Battery level healthy · Estimated 6.2 h runtime'}</small></div>}
    {asset.kind === 'dock' && <div className="capacity-block"><div className="capacity-heading"><span>Load completion</span><b>{asset.progress}%</b></div><div className="progress-track"><i style={{ width: `${asset.progress}%` }} /></div></div>}
    <div className="inspector-section-title"><span>ASSET INFORMATION</span><button className="icon-button small"><MoreHorizontal size={16} /></button></div>
    <div className="detail-list">{details.map(([label, value]) => <div className="detail-row" key={label}><span>{label}</span><b>{value}</b></div>)}</div>
    {asset.kind === 'pallet' && <div className="asset-note"><span className="note-icon"><Activity size={14} /></span><div><b>Traceability verified</b><small>All inbound scan events synced · 08:14 AM</small></div></div>}
    {asset.kind === 'forklift' && <div className="asset-note"><span className="note-icon"><Activity size={14} /></span><div><b>Telematics connected</b><small>Last heartbeat · 4 seconds ago</small></div></div>}
  </>;
}

function Inspector({ site }) {
  const selectedId = useWaretrackStore((s) => s.selectedId);
  const select = useWaretrackStore((s) => s.select);
  const asset = assetCatalog.find((a) => a.id === selectedId);
  return <aside className="inspector-panel panel">
    <div className="panel-heading inspector-heading">
      <div><span className="eyebrow">LIVE INSPECTOR</span><h3>{asset ? 'Asset details' : 'Site overview'}</h3></div>
      {asset && <button className="clear-selection" onClick={() => select(null)}><X size={13} /> Clear</button>}
      {!asset && <button className="icon-button"><MoreHorizontal size={17} /></button>}
    </div>
    <div className="inspector-body">{asset ? <AssetInspector asset={asset} site={site} /> : <SiteOverview site={site} />}</div>
    <div className="inspector-footer"><span><span className="footer-live-dot" /> TELEMETRY SYNCED</span><span>Updated just now</span></div>
  </aside>;
}

function OperationsPanel() {
  const activeTab = useWaretrackStore((s) => s.activeTab);
  const setTab = useWaretrackStore((s) => s.setTab);
  const select = useWaretrackStore((s) => s.select);
  const currentItems = operations[activeTab];
  const count = { docks: '14 / 18', forklifts: '03 ACTIVE', trucks: '12 ON SITE' }[activeTab];
  const icons = { docks: <DoorOpen size={14} />, forklifts: <Construction size={14} />, trucks: <Truck size={14} /> };
  return <section className="operations-panel panel">
    <div className="panel-heading operations-heading">
      <div><span className="eyebrow">FLOOR OPERATIONS</span><h3>Operations queue <span className="heading-count">{count}</span></h3></div>
      <button className="icon-button"><MoreHorizontal size={17} /></button>
    </div>
    <div className="ops-tabs">{Object.keys(operations).map((tab) => <button key={tab} className={activeTab === tab ? 'active' : ''} onClick={() => setTab(tab)}>{icons[tab]} {tab}<span>{operations[tab].length}</span></button>)}</div>
    <div className="ops-list">{currentItems.map((item) => <button key={item.id} className="ops-row" onClick={() => select(item.id)}>
      <span className={`ops-item-icon ${activeTab}`}>{icons[activeTab]}</span>
      <span className="ops-item-main"><b>{item.title}</b><small>{item.subtitle}</small></span>
      <span className="ops-item-progress"><b>{item.progress}%</b><i><em style={{ width: `${item.progress}%` }} /></i></span>
      <StatusPill status={item.status} />
    </button>)}</div>
    <div className="ops-footer"><span>Showing active {activeTab}</span><button>View all <ArrowUpRight size={12} /></button></div>
  </section>;
}

function FooterBar({ site }) {
  const seconds = useWaretrackStore((s) => s.simulationSeconds);
  const paused = useWaretrackStore((s) => s.paused);
  const speed = useWaretrackStore((s) => s.speed);
  const setSpeed = useWaretrackStore((s) => s.setSpeed);
  const hh = String(8 + Math.floor((seconds % 28800) / 3600)).padStart(2, '0');
  const mm = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
  const ss = String(Math.floor(seconds % 60)).padStart(2, '0');
  return <footer className="footer-bar">
    <div className="footer-left"><span className="footer-brand-dot" /> <b>WARETRACK SIMULATION</b><span className="footer-divider" /> <span>{site.short.toUpperCase()} FACILITY</span></div>
    <div className="footer-center"><span className="footer-status"><i /> {paused ? 'SIMULATION PAUSED' : 'SIMULATION RUNNING'}</span><span className="footer-divider" /><span className="simulation-clock"><Clock3 size={12} /> {hh}:{mm}:{ss}</span></div>
    <div className="footer-right"><span>SPEED</span>{[1, 2, 4].map((n) => <button key={n} className={speed === n ? 'active' : ''} onClick={() => setSpeed(n)}>{n}×</button>)}<button className="reset-button" onClick={() => useWaretrackStore.getState().setSite(site.id)} title="Reset selected asset and camera"><RotateCcw size={12} /></button></div>
  </footer>;
}

export default function App() {
  const activeSiteId = useWaretrackStore((s) => s.activeSiteId);
  const setSite = useWaretrackStore((s) => s.setSite);
  const select = useWaretrackStore((s) => s.select);
  const site = sites.find((s) => s.id === activeSiteId) || sites[0];
  const chooseAsset = (id) => { select(id); };
  return <div className="app-shell">
    <Header site={site} onSelectSite={setSite} onSelectAsset={chooseAsset} />
    <KpiStrip site={site} />
    <main className="dashboard-grid">
      <section className="scene-panel panel"><WarehouseScene site={site} /></section>
      <Inspector site={site} />
      <ShipmentTracker site={site} />
      <OperationsPanel />
    </main>
    <FooterBar site={site} />
    <div className="app-copyright">WARETRACK <span>·</span> LOGISTICS INTELLIGENCE PLATFORM <span>·</span> DEMO ENVIRONMENT</div>
  </div>;
}
