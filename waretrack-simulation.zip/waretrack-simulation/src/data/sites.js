export const sites = [
  {
    id: 'riverside', name: 'Riverside Hub', short: 'Riverside', city: 'Memphis, TN', type: 'Regional distribution',
    status: 'Operational', capacity: 82, stock: 12480, trucks: 12, onTime: 98.4, docks: 18, activeDocks: 14,
    inbound: 28, outbound: 46, putAway: 186, color: '#4f8b87', footprint: [9.2, 7.2], building: 'RIVERSIDE',
    shipments: ['SHP-76442', 'SHP-76453', 'SHP-76481'],
  },
  {
    id: 'southfield', name: 'Southfield Cross-Dock', short: 'Southfield', city: 'Detroit, MI', type: 'Cross-dock terminal',
    status: 'Operational', capacity: 67, stock: 8420, trucks: 19, onTime: 96.8, docks: 24, activeDocks: 21,
    inbound: 35, outbound: 52, putAway: 92, color: '#6d86a4', footprint: [10.5, 6.4], building: 'SOUTHFIELD',
    shipments: ['SHP-88302', 'SHP-88319', 'SHP-88344'],
  },
  {
    id: 'northgate', name: 'Northgate DC', short: 'Northgate', city: 'Columbus, OH', type: 'Distribution center',
    status: 'Operational', capacity: 91, stock: 22160, trucks: 8, onTime: 99.1, docks: 20, activeDocks: 16,
    inbound: 18, outbound: 31, putAway: 244, color: '#7a8e6d', footprint: [10.2, 8.1], building: 'NORTHGATE',
    shipments: ['SHP-90115', 'SHP-90128', 'SHP-90160'],
  },
  {
    id: 'eastport', name: 'Eastport Cold Chain', short: 'Eastport', city: 'Newark, NJ', type: 'Temperature controlled',
    status: 'Operational', capacity: 74, stock: 6340, trucks: 10, onTime: 97.6, docks: 12, activeDocks: 9,
    inbound: 14, outbound: 22, putAway: 74, color: '#6b9bb4', footprint: [8.8, 7.4], building: 'EASTPORT',
    shipments: ['SHP-61207', 'SHP-61233', 'SHP-61264'],
  },
  {
    id: 'westgate', name: 'Westgate Robotics Hub', short: 'Westgate', city: 'Phoenix, AZ', type: 'Automated fulfillment',
    status: 'Operational', capacity: 88, stock: 18720, trucks: 7, onTime: 99.4, docks: 16, activeDocks: 13,
    inbound: 22, outbound: 39, putAway: 318, color: '#9b8768', footprint: [10.4, 7.8], building: 'WESTGATE',
    shipments: ['SHP-43016', 'SHP-43042', 'SHP-43088'],
  },
];

export const assetCatalog = [
  { id: 'PLT-901', kind: 'pallet', name: 'Pallet PLT-901', sku: 'SKU-44821', status: 'Staged', quantity: 48, weight: '612 kg', location: 'Zone A · Row 04', lot: 'LOT-2408-19', received: 'Nov 22, 2026' },
  { id: 'PLT-914', kind: 'pallet', name: 'Pallet PLT-914', sku: 'SKU-88210', status: 'Picked', quantity: 32, weight: '408 kg', location: 'Zone B · Row 02', lot: 'LOT-2411-02', received: 'Nov 23, 2026' },
  { id: 'PLT-927', kind: 'pallet', name: 'Pallet PLT-927', sku: 'SKU-56004', status: 'Staged', quantity: 36, weight: '472 kg', location: 'Zone A · Row 06', lot: 'LOT-2410-17', received: 'Nov 22, 2026' },
  { id: 'PLT-933', kind: 'pallet', name: 'Pallet PLT-933', sku: 'SKU-73018', status: 'Available', quantity: 24, weight: '316 kg', location: 'Zone C · Row 01', lot: 'LOT-2411-08', received: 'Nov 24, 2026' },
  { id: 'FL-01', kind: 'forklift', name: 'Forklift FL-01', model: 'Crown FC 5200', status: 'Loading truck', battery: 86, task: 'Load SHP-76442', carrying: '1 pallet · PLT-901', moves: 142, speed: '4.2 km/h', charger: 'C1 · Available' },
  { id: 'FL-10', kind: 'forklift', name: 'Forklift FL-10', model: 'Toyota 8FBCU25', status: 'Picking', battery: 64, task: 'Move to Zone B', carrying: 'Empty', moves: 98, speed: '2.8 km/h', charger: 'C2 · Standby' },
  { id: 'FL-12', kind: 'forklift', name: 'Forklift FL-12', model: 'Jungheinrich EFG', status: 'Charging', battery: 18, task: 'Battery recharge', carrying: 'Empty', moves: 76, speed: '0 km/h', charger: 'C1 · Connected' },
  { id: 'C1', kind: 'charger', name: 'Charging station C1', status: 'Available', output: '80 kW', connector: 'CCS Type 2', bay: 'Utility lane · 01', utilization: '62%' },
  { id: 'TRK-2205', kind: 'truck', name: 'Truck TRK-2205', carrier: 'Bluepeak Freight', status: 'Unloading', eta: 'Arrived 08:42', shipment: 'SHP-76442', dock: 'D-04', cargo: '18 pallets · 8.4 t', route: 'Memphis → Riverside' },
  { id: 'TRK-2218', kind: 'truck', name: 'Truck TRK-2218', carrier: 'Nordline Logistics', status: 'In yard', eta: 'ETA 09:18', shipment: 'SHP-76453', dock: 'D-07', cargo: '24 pallets · 11.2 t', route: 'Nashville → Riverside' },
  { id: 'TRK-2231', kind: 'truck', name: 'Truck TRK-2231', carrier: 'Harborline Freight', status: 'Departing', eta: 'Depart 09:05', shipment: 'SHP-76481', dock: 'D-12', cargo: '12 pallets · 5.6 t', route: 'Riverside → St. Louis' },
  { id: 'D-04', kind: 'dock', name: 'Dock bay D-04', status: 'Occupied', door: 'Door 04', truck: 'TRK-2205', shipment: 'SHP-76442', progress: 72 },
  { id: 'D-07', kind: 'dock', name: 'Dock bay D-07', status: 'Reserved', door: 'Door 07', truck: 'TRK-2218', shipment: 'SHP-76453', progress: 34 },
  { id: 'D-12', kind: 'dock', name: 'Dock bay D-12', status: 'Departing', door: 'Door 12', truck: 'TRK-2231', shipment: 'SHP-76481', progress: 91 },
];

export const shipmentSteps = [
  { name: 'Order confirmed', time: '07:12 AM', done: true },
  { name: 'Picked', time: '08:06 AM', done: true },
  { name: 'Loaded', time: '08:42 AM', done: true },
  { name: 'In transit', time: '09:18 AM', current: true },
  { name: 'Delivered', time: 'ETA 11:40 AM', done: false },
];

export const operations = {
  docks: [
    { id: 'D-04', title: 'Dock 04', subtitle: 'TRK-2205 · Bluepeak', status: 'Unloading', progress: 72 },
    { id: 'D-07', title: 'Dock 07', subtitle: 'TRK-2218 · Nordline', status: 'Reserved', progress: 34 },
    { id: 'D-12', title: 'Dock 12', subtitle: 'TRK-2231 · Harborline', status: 'Departing', progress: 91 },
    { id: 'D-15', title: 'Dock 15', subtitle: 'Available for inbound', status: 'Available', progress: 0 },
  ],
  forklifts: [
    { id: 'FL-01', title: 'FL-01', subtitle: 'Loading · PLT-901', status: 'Active', progress: 76 },
    { id: 'FL-10', title: 'FL-10', subtitle: 'Picking · Zone B', status: 'Active', progress: 42 },
    { id: 'FL-12', title: 'FL-12', subtitle: 'Charging · C1', status: 'Charging', progress: 18 },
  ],
  trucks: [
    { id: 'TRK-2205', title: 'TRK-2205', subtitle: 'Bluepeak Freight', status: 'Unloading', progress: 72 },
    { id: 'TRK-2218', title: 'TRK-2218', subtitle: 'Nordline Logistics', status: 'In yard', progress: 34 },
    { id: 'TRK-2231', title: 'TRK-2231', subtitle: 'Harborline Freight', status: 'Departing', progress: 91 },
  ],
};
