import React, { useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Html, OrbitControls, RoundedBox } from '@react-three/drei';
import * as THREE from 'three';
import { useWaretrackStore } from '../store/useWaretrackStore';

const focusPoints = {
  'PLT-901': [-5.5, 0, 0.4], 'PLT-914': [-2.7, 0, -0.1],
  'FL-01': [-4.2, 0, 2.4], 'FL-10': [-1.2, 0, 1.6], 'FL-12': [5.6, 0, -2.8],
  C1: [5.6, 0, -2.8], 'TRK-2205': [5.3, 0, 5.3], 'TRK-2218': [8.3, 0, 5.4], 'TRK-2231': [2.2, 0, 5.3],
  'D-04': [-7.3, 0, 2.0], 'D-07': [-4.8, 0, 2.0], 'D-12': [-0.5, 0, 2.0],
};

function CameraFocus({ controlsRef }) {
  const selectedId = useWaretrackStore((s) => s.selectedId);
  const { camera } = useThree();
  const target = useRef(new THREE.Vector3(0, 0, 0));
  useFrame(() => {
    const p = selectedId ? focusPoints[selectedId] : [0, 0, 0];
    const next = new THREE.Vector3(p[0], p[1], p[2]);
    target.current.lerp(next, 0.035);
    if (controlsRef.current) {
      controlsRef.current.target.copy(target.current);
      controlsRef.current.update();
    }
  });
  return null;
}

function SceneTicker() {
  const accumulator = useRef(0);
  useFrame((_, delta) => {
    const state = useWaretrackStore.getState();
    if (state.paused) return;
    accumulator.current += delta * state.speed;
    if (accumulator.current >= 0.5) {
      state.tick(accumulator.current);
      accumulator.current = 0;
    }
  });
  return null;
}

function Tag({ children, selected = false, color = 'blue' }) {
  return <div className={`scene-tag ${selected ? 'is-selected' : ''} tag-${color}`}>{children}</div>;
}

function Ground() {
  return (
    <group>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.16, 0]} receiveShadow>
        <planeGeometry args={[38, 26]} />
        <meshStandardMaterial color="#aab7b5" roughness={1} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.145, 6.0]}>
        <planeGeometry args={[38, 4.4]} />
        <meshStandardMaterial color="#515e6a" roughness={0.95} />
      </mesh>
      {Array.from({ length: 12 }).map((_, i) => (
        <mesh key={i} rotation={[-Math.PI / 2, 0, 0]} position={[-16 + i * 2.9, -0.13, 6.0]}>
          <planeGeometry args={[1.3, 0.12]} />
          <meshBasicMaterial color="#d9e0d9" />
        </mesh>
      ))}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[4.8, -0.135, 1.1]}>
        <planeGeometry args={[12.4, 0.16]} />
        <meshBasicMaterial color="#e4e5dc" />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[4.7, -0.13, -3.5]}>
        <planeGeometry args={[0.14, 9.8]} />
        <meshBasicMaterial color="#e1e4dc" />
      </mesh>
      {[-8, -5.4, -2.8, -0.2].map((x) => (
        <mesh key={x} rotation={[-Math.PI / 2, 0, 0]} position={[x, -0.11, 3.0]}>
          <planeGeometry args={[0.09, 1.1]} />
          <meshBasicMaterial color="#d8dcd4" />
        </mesh>
      ))}
      <mesh position={[-12.5, 0.42, -4.1]} castShadow>
        <boxGeometry args={[2.4, 0.8, 1.5]} />
        <meshStandardMaterial color="#9eafa3" />
      </mesh>
      <mesh position={[12.6, 0.28, -3.3]} castShadow>
        <boxGeometry args={[2.6, 0.5, 1.3]} />
        <meshStandardMaterial color="#9eafa3" />
      </mesh>
      {[-13.4, -11.7, 11.8, 13.4].map((x, i) => (
        <group key={x} position={[x, 0, i < 2 ? -4.1 : -3.3]}>
          <mesh position={[0, 0.9, 0]} castShadow>
            <cylinderGeometry args={[0.08, 0.14, 1.8, 6]} />
            <meshStandardMaterial color="#705b48" />
          </mesh>
          <mesh position={[0, 1.9, 0]} castShadow>
            <icosahedronGeometry args={[0.72, 0]} />
            <meshStandardMaterial color="#6b8b74" flatShading />
          </mesh>
        </group>
      ))}
    </group>
  );
}

function Warehouse({ site }) {
  const wall = site.id === 'eastport' ? '#b8d0d6' : '#bec8c7';
  const roof = site.id === 'westgate' ? '#3f5263' : '#526474';
  return (
    <group>
      <mesh position={[-5.0, 0.02, -1.7]} receiveShadow>
        <boxGeometry args={[site.footprint[0] + 0.5, 0.18, site.footprint[1] + 0.5]} />
        <meshStandardMaterial color="#8f9e9d" />
      </mesh>
      <mesh position={[-5.0, 1.45, -5.25]} castShadow receiveShadow>
        <boxGeometry args={[site.footprint[0], 2.9, 0.22]} />
        <meshStandardMaterial color={wall} />
      </mesh>
      <mesh position={[-9.55, 1.45, -1.7]} castShadow receiveShadow>
        <boxGeometry args={[0.22, 2.9, site.footprint[1]]} />
        <meshStandardMaterial color={wall} />
      </mesh>
      <mesh position={[-0.45, 1.45, -1.7]} castShadow receiveShadow>
        <boxGeometry args={[0.22, 2.9, site.footprint[1]]} />
        <meshStandardMaterial color={wall} />
      </mesh>
      <mesh position={[-5.0, 2.98, -3.55]} castShadow>
        <boxGeometry args={[site.footprint[0] + 0.35, 0.22, site.footprint[1] * 0.48]} />
        <meshStandardMaterial color={roof} roughness={0.88} />
      </mesh>
      <mesh position={[-5.0, 3.115, -1.7]}>
        <boxGeometry args={[site.footprint[0] - 0.4, 0.04, 0.18]} />
        <meshStandardMaterial color={site.color} emissive={site.color} emissiveIntensity={0.15} />
      </mesh>
      <mesh position={[-5.0, 2.22, -5.11]}>
        <boxGeometry args={[3.1, 0.62, 0.04]} />
        <meshStandardMaterial color="#263848" />
      </mesh>
      <Html position={[-5.0, 2.22, -5.03]} center distanceFactor={10}>
        <div className="building-sign"><span>WARETRACK</span><b>{site.building}</b></div>
      </Html>
      {[-8.0, -5.0, -2.0].map((x, i) => (
        <group key={x} position={[x, 0, 2.0]}>
          <mesh position={[0, 1.28, 0]}>
            <boxGeometry args={[2.0, 2.35, 0.16]} />
            <meshStandardMaterial color="#657785" />
          </mesh>
          <mesh position={[0, 1.14, 0.11]}>
            <boxGeometry args={[1.35, 1.75, 0.08]} />
            <meshStandardMaterial color="#233849" />
          </mesh>
          <mesh position={[0, 0.22, 0.17]}>
            <boxGeometry args={[1.45, 0.11, 0.12]} />
            <meshStandardMaterial color={i === 0 ? '#54c9a3' : '#d2a86b'} />
          </mesh>
          <Html position={[0, 2.62, 0.15]} center distanceFactor={12}>
            <div className="bay-number">D-{String([4, 7, 12][i]).padStart(2, '0')}</div>
          </Html>
        </group>
      ))}
      <mesh position={[-5.0, 0.14, -1.8]} receiveShadow>
        <boxGeometry args={[7.5, 0.08, 5.7]} />
        <meshStandardMaterial color="#a9b7b2" />
      </mesh>
      {[-7.8, -5.6, -3.4, -1.2].map((x, i) => (
        <mesh key={x} position={[x, 0.2, -1.9]}>
          <boxGeometry args={[0.045, 0.025, 5.1]} />
          <meshBasicMaterial color="#e2e1d4" />
        </mesh>
      ))}
    </group>
  );
}

function Pallet({ id, position, color = '#c99561', selected }) {
  const select = useWaretrackStore((s) => s.select);
  return (
    <group position={position} onClick={(e) => { e.stopPropagation(); select(id); }}>
      <mesh position={[0, 0.12, 0]} castShadow>
        <boxGeometry args={[0.95, 0.18, 0.78]} />
        <meshStandardMaterial color="#8d6849" />
      </mesh>
      {[0, 1, 2].map((i) => (
        <mesh key={i} position={[-0.28 + i * 0.28, 0.48, 0]} castShadow>
          <boxGeometry args={[0.27, 0.55, 0.68]} />
          <meshStandardMaterial color={color} />
        </mesh>
      ))}
      <mesh position={[0, 0.78, 0]} castShadow>
        <boxGeometry args={[0.89, 0.08, 0.72]} />
        <meshStandardMaterial color="#d4b083" />
      </mesh>
      {selected && <mesh position={[0, 0.035, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.64, 0.78, 32]} />
        <meshBasicMaterial color="#39d6ba" side={THREE.DoubleSide} />
      </mesh>}
      <Html position={[0, 1.28, 0]} center distanceFactor={11}>
        <Tag selected={selected} color="amber">{id}</Tag>
      </Html>
    </group>
  );
}

function Forklift({ id, start, selected, color = '#d9a342', moving = true }) {
  const group = useRef();
  const select = useWaretrackStore((s) => s.select);
  const phase = id === 'FL-01' ? 0.25 : id === 'FL-10' ? 2.4 : 4.2;
  useFrame((_, delta) => {
    const state = useWaretrackStore.getState();
    if (!group.current || state.paused || !moving) return;
    const t = state.simulationSeconds * 0.38 + phase;
    group.current.position.x = start[0] + Math.sin(t) * 0.82;
    group.current.position.z = start[2] + Math.cos(t * 0.68) * 0.38;
    group.current.rotation.y = Math.sin(t + 0.55) * 0.22;
  });
  return (
    <group ref={group} position={start} onClick={(e) => { e.stopPropagation(); select(id); }}>
      <mesh position={[0, 0.42, 0]} castShadow>
        <boxGeometry args={[1.18, 0.66, 0.72]} />
        <meshStandardMaterial color={color} />
      </mesh>
      <mesh position={[-0.1, 0.95, -0.02]}>
        <boxGeometry args={[0.62, 0.82, 0.55]} />
        <meshStandardMaterial color="#465968" transparent opacity={0.76} />
      </mesh>
      <mesh position={[0.44, 0.92, 0]}>
        <boxGeometry args={[0.1, 1.55, 0.1]} />
        <meshStandardMaterial color="#334754" />
      </mesh>
      <mesh position={[0.75, 0.18, 0]}>
        <boxGeometry args={[0.82, 0.08, 0.08]} />
        <meshStandardMaterial color="#e8c47b" />
      </mesh>
      {[-0.42, 0.42].map((x) => [-0.38, 0.38].map((z) => (
        <mesh key={`${x}-${z}`} position={[x, 0.22, z]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <cylinderGeometry args={[0.18, 0.18, 0.13, 12]} />
          <meshStandardMaterial color="#26313a" />
        </mesh>
      )))}
      <mesh position={[0.88, 0.11, -0.2]}>
        <boxGeometry args={[0.85, 0.055, 0.055]} />
        <meshStandardMaterial color="#a8b6bb" />
      </mesh>
      <mesh position={[0.88, 0.11, 0.2]}>
        <boxGeometry args={[0.85, 0.055, 0.055]} />
        <meshStandardMaterial color="#a8b6bb" />
      </mesh>
      {selected && <mesh position={[0, 0.04, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.82, 0.94, 32]} />
        <meshBasicMaterial color="#39d6ba" side={THREE.DoubleSide} />
      </mesh>}
      <Html position={[0, 1.58, 0]} center distanceFactor={11}>
        <Tag selected={selected} color="gold">{id}</Tag>
      </Html>
    </group>
  );
}

function Truck({ id, carrier, selected, startX, color = '#397e9b', phase = 0, route = true }) {
  const group = useRef();
  const select = useWaretrackStore((s) => s.select);
  useFrame(() => {
    const state = useWaretrackStore.getState();
    if (!group.current || !route || state.paused) return;
    const t = state.simulationSeconds * 0.2 + phase;
    group.current.position.x = startX + Math.sin(t) * 1.25;
    group.current.position.z = 5.55 + Math.cos(t * 0.8) * 0.22;
    group.current.rotation.y = Math.cos(t) * 0.08;
  });
  return (
    <group ref={group} position={[startX, 0, 5.55]} onClick={(e) => { e.stopPropagation(); select(id); }}>
      <mesh position={[-0.95, 0.72, 0]} castShadow>
        <boxGeometry args={[2.45, 1.05, 1.42]} />
        <meshStandardMaterial color="#e6e9e5" />
      </mesh>
      <mesh position={[0.87, 0.69, 0]} castShadow>
        <boxGeometry args={[1.12, 1.18, 1.42]} />
        <meshStandardMaterial color={color} />
      </mesh>
      <mesh position={[1.12, 1.0, 0]}>
        <boxGeometry args={[0.08, 0.42, 1.15]} />
        <meshStandardMaterial color="#a8c4ce" transparent opacity={0.78} />
      </mesh>
      <mesh position={[-0.95, 1.28, 0]}>
        <boxGeometry args={[2.2, 0.08, 1.2]} />
        <meshStandardMaterial color="#d6dedb" />
      </mesh>
      {[-1.55, -0.15, 0.7, 1.05].map((x, i) => (
        <mesh key={i} position={[x, 0.25, i > 1 ? 0.76 : -0.76]} rotation={[Math.PI / 2, 0, 0]} castShadow>
          <cylinderGeometry args={[0.24, 0.24, 0.14, 14]} />
          <meshStandardMaterial color="#26323d" />
        </mesh>
      ))}
      <mesh position={[-0.98, 0.74, 0.72]}>
        <boxGeometry args={[2.1, 0.22, 0.025]} />
        <meshBasicMaterial color={color} />
      </mesh>
      {selected && <mesh position={[0, 0.04, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[1.8, 2.0, 36]} />
        <meshBasicMaterial color="#39d6ba" side={THREE.DoubleSide} />
      </mesh>}
      <Html position={[0, 1.76, 0]} center distanceFactor={12}>
        <Tag selected={selected} color="blue">{id}<span className="tag-sub">{carrier}</span></Tag>
      </Html>
    </group>
  );
}

function Charger({ selected }) {
  const select = useWaretrackStore((s) => s.select);
  return (
    <group position={[5.7, 0, -2.6]} onClick={(e) => { e.stopPropagation(); select('C1'); }}>
      <mesh position={[0, 0.67, 0]} castShadow>
        <boxGeometry args={[0.68, 1.28, 0.55]} />
        <meshStandardMaterial color="#344e5c" />
      </mesh>
      <mesh position={[0, 0.83, 0.29]}>
        <boxGeometry args={[0.36, 0.35, 0.04]} />
        <meshStandardMaterial color="#3bd0ad" emissive="#2ca98d" emissiveIntensity={0.45} />
      </mesh>
      <mesh position={[0.42, 0.36, 0.12]} rotation={[0, 0, -0.4]}>
        <cylinderGeometry args={[0.035, 0.035, 0.7, 8]} />
        <meshStandardMaterial color="#252f38" />
      </mesh>
      {selected && <mesh position={[0, 0.04, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.55, 0.68, 28]} />
        <meshBasicMaterial color="#39d6ba" side={THREE.DoubleSide} />
      </mesh>}
      <Html position={[0, 1.62, 0]} center distanceFactor={11}><Tag selected={selected} color="mint">C1 · Charger</Tag></Html>
    </group>
  );
}

function DockMarker({ id, position, selected }) {
  const select = useWaretrackStore((s) => s.select);
  return (
    <group position={position} onClick={(e) => { e.stopPropagation(); select(id); }}>
      <mesh position={[0, 0.055, 0]}>
        <boxGeometry args={[2.1, 0.08, 1.05]} />
        <meshStandardMaterial color={selected ? '#38b99c' : '#7b8d91'} />
      </mesh>
      <mesh position={[0, 0.11, 0]}>
        <boxGeometry args={[1.78, 0.025, 0.76]} />
        <meshStandardMaterial color="#dfe5db" />
      </mesh>
      <Html position={[0, 0.8, 0]} center distanceFactor={13}><Tag selected={selected} color="slate">{id}</Tag></Html>
    </group>
  );
}

function YardScene({ site }) {
  const selectedId = useWaretrackStore((s) => s.selectedId);
  const controlsRef = useRef();
  const pallets = useMemo(() => [
    { id: 'PLT-901', position: [-6.0, 0.2, -0.4], color: '#bd936b' },
    { id: 'PLT-914', position: [-2.8, 0.2, -1.25], color: '#d0a26c' },
    { id: 'PLT-927', position: [-7.7, 0.2, -2.7], color: '#9daeb1' },
    { id: 'PLT-933', position: [-3.2, 0.2, -3.0], color: '#b7895e' },
  ], []);
  return (
    <>
      <Canvas shadows dpr={[1, 1.65]} camera={{ position: [16.5, 18.5, 17.5], fov: 36, near: 0.1, far: 100 }} gl={{ antialias: true }}>
        <color attach="background" args={['#dce4e1']} />
        <fog attach="fog" args={['#dce4e1', 28, 58]} />
        <ambientLight intensity={0.78} />
        <directionalLight position={[8, 18, 7]} intensity={1.45} castShadow shadow-mapSize={[2048, 2048]} shadow-camera-far={55} shadow-camera-left={-22} shadow-camera-right={22} shadow-camera-top={22} shadow-camera-bottom={-22} />
        <hemisphereLight args={['#e9f3f4', '#718079', 0.55]} />
        <Ground />
        <Warehouse site={site} />
        {pallets.map((p) => <Pallet key={p.id} {...p} selected={selectedId === p.id} />)}
        <Forklift id="FL-01" start={[-4.7, 0, 2.55]} selected={selectedId === 'FL-01'} />
        <Forklift id="FL-10" start={[-1.4, 0, 1.1]} selected={selectedId === 'FL-10'} color="#e4bd62" />
        <Forklift id="FL-12" start={[5.7, 0, -1.25]} selected={selectedId === 'FL-12'} color="#a4b1b0" moving={false} />
        <Charger selected={selectedId === 'C1'} />
        <Truck id="TRK-2205" carrier="BLUEPEAK" selected={selectedId === 'TRK-2205'} startX={4.3} color="#3d809e" phase={0.1} />
        <Truck id="TRK-2218" carrier="NORDLINE" selected={selectedId === 'TRK-2218'} startX={9.0} color="#607d9e" phase={2.1} />
        <Truck id="TRK-2231" carrier="HARBORLINE" selected={selectedId === 'TRK-2231'} startX={-0.5} color="#b67c52" phase={4.1} />
        <DockMarker id="D-04" position={[-7.3, 0, 2.8]} selected={selectedId === 'D-04'} />
        <DockMarker id="D-07" position={[-4.5, 0, 2.8]} selected={selectedId === 'D-07'} />
        <DockMarker id="D-12" position={[-1.5, 0, 2.8]} selected={selectedId === 'D-12'} />
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.12, 0]} onClick={() => useWaretrackStore.getState().select(null)}>
          <planeGeometry args={[38, 26]} />
          <meshBasicMaterial transparent opacity={0} />
        </mesh>
        <OrbitControls ref={controlsRef} enableDamping dampingFactor={0.08} minDistance={12} maxDistance={34} maxPolarAngle={Math.PI / 2.12} minPolarAngle={Math.PI / 5.3} />
        <CameraFocus controlsRef={controlsRef} />
        <SceneTicker />
      </Canvas>
    </>
  );
}

export default function WarehouseScene({ site }) {
  return (
    <div className="scene-canvas-wrap">
      <YardScene site={site} />
      <div className="scene-topline">
        <div><span className="scene-dot" /> LIVE FACILITY VIEW <span className="scene-sep">/</span> {site.type.toUpperCase()}</div>
        <div className="scene-top-actions"><span>CAM 01 · ISOMETRIC</span><span className="scene-move-hint">Drag to orbit · Scroll to zoom</span></div>
      </div>
      <div className="scene-legend">
        <span><i className="legend-box pallet" /> Cargo</span>
        <span><i className="legend-box forklift" /> Forklift</span>
        <span><i className="legend-box truck" /> Truck</span>
        <span><i className="legend-box dock" /> Dock bay</span>
      </div>
      <div className="scene-coordinate">35°08' N&nbsp;&nbsp; 89°55' W <span>·</span> YARD ZONE A</div>
    </div>
  );
}
