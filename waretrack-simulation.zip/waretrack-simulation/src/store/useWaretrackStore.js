import { create } from 'zustand';

export const useWaretrackStore = create((set) => ({
  activeSiteId: 'riverside',
  selectedId: null,
  activeTab: 'docks',
  paused: false,
  speed: 1,
  simulationSeconds: 0,
  search: '',
  setSite: (activeSiteId) => set({ activeSiteId, selectedId: null }),
  select: (selectedId) => set({ selectedId }),
  setTab: (activeTab) => set({ activeTab }),
  togglePause: () => set((s) => ({ paused: !s.paused })),
  setSpeed: (speed) => set({ speed }),
  tick: (delta) => set((s) => ({ simulationSeconds: s.simulationSeconds + delta })),
  setSearch: (search) => set({ search }),
}));
