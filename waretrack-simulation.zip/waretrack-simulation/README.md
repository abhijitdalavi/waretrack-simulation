# WareTrack — Warehouse & Freight Simulation

A Vite + React + React Three Fiber demo of a multi-facility warehouse operations command center. It uses simulated telemetry and browser-side motion; no backend, live WMS, GPS, or IoT connection is required.

## Run locally

Prerequisites: Node.js 20+ and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite (usually `http://localhost:5173`). To create a production build:

```bash
npm run build
npm run preview
```

## Included

- Five facility profiles: Riverside Hub, Southfield Cross-Dock, Northgate DC, Eastport Cold Chain, and Westgate Robotics Hub.
- Interactive isometric 3D yard with warehouse shell, dock bays, pallets, forklifts, trucks, charging station, yard lanes, road markings, and perimeter greenery.
- Click-to-select 3D assets, floating labels, smooth camera focus, orbit/zoom controls, and a contextual inspector.
- Animated truck and forklift movement, simulated KPI refresh, pause/resume, and 1× / 2× / 4× speed control.
- Search across sites and assets, shipment milestone tracker, and Docks / Forklifts / Trucks operations tabs.
- Responsive dark SaaS telemetry HUD.

## Project layout

```text
src/
  App.jsx                       UI shell and dashboard panels
  components/WarehouseScene.jsx  React Three Fiber scene + simulated motion
  data/sites.js                 Facility, asset, shipment, and operations mock data
  store/useWaretrackStore.js    Shared Zustand state
  styles.css                    Dashboard and responsive styles
  main.jsx                      React entry point
```

## Extending the demo

- Replace `src/data/sites.js` with API-fed facility, shipment, inventory, and asset telemetry.
- Add a backend/WebSocket subscription and update the Zustand store for live events.
- Extend `focusPoints` and the scene components in `WarehouseScene.jsx` when adding asset types or new facility-specific geometry.
- Connect command actions to your WMS/TMS only after adding authentication, authorization, validation, and audit logging.

All names, counts, shipments, statuses, and KPI values in this starter are illustrative simulation data.
